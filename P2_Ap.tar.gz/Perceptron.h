#ifndef PERCEPTRON_H_
#define PERCEPTRON_H_

#define ARMA_DONT_USE_WRAPPER
#include <armadillo>
#include <iostream>
#include <vector>

typedef struct Percept{
  arma::mat p;
  arma::mat t;
}Percept;

class Perceptron {
public:
  Perceptron(){
  }
  Perceptron(arma::mat, arma::mat, arma::mat, arma::mat);
  void Train();
  arma::mat getWeight();
  arma::mat getBias();

protected:
  int n, m, c, e;
  arma::mat W, A, B, b;
  std::vector<Percept> percept;
  arma::mat hardLim(arma::mat);
  arma::mat weightedSum(arma::mat, arma::mat, arma::mat);
};

#endif
